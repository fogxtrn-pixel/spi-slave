###############################################################################
# Created by write_sdc
###############################################################################
current_design h04_spi_slave
###############################################################################
# Timing Constraints
###############################################################################
create_clock -name sclk -period 10.0000 [get_ports {sclk}]
create_clock -name cs_n -period 10.0000 [get_ports {cs_n}]
set_clock_groups -name group1 -asynchronous \
 -group [get_clocks {cs_n}]\
 -group [get_clocks {sclk}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {mosi}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {tx_byte[0]}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {tx_byte[1]}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {tx_byte[2]}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {tx_byte[3]}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {tx_byte[4]}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {tx_byte[5]}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {tx_byte[6]}]
set_input_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {tx_byte[7]}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {miso}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {rx_byte[0]}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {rx_byte[1]}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {rx_byte[2]}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {rx_byte[3]}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {rx_byte[4]}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {rx_byte[5]}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {rx_byte[6]}]
set_output_delay 1.0000 -clock [get_clocks {sclk}] -add_delay [get_ports {rx_byte[7]}]
###############################################################################
# Environment
###############################################################################
###############################################################################
# Design Rules
###############################################################################

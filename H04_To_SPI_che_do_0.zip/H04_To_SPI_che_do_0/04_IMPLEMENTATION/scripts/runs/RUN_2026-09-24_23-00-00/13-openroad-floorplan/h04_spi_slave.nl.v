module h04_spi_slave (cs_n,
    miso,
    mosi,
    sclk,
    rx_byte,
    tx_byte);
 input cs_n;
 output miso;
 input mosi;
 input sclk;
 output [7:0] rx_byte;
 input [7:0] tx_byte;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire _007_;
 wire _008_;
 wire _009_;
 wire _010_;
 wire _011_;
 wire _012_;
 wire _013_;
 wire _014_;
 wire _015_;
 wire _016_;
 wire _017_;
 wire _018_;
 wire _019_;
 wire _020_;
 wire _021_;
 wire _022_;
 wire _023_;
 wire _024_;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire \rx_count[0] ;
 wire \rx_count[1] ;
 wire \rx_count[2] ;
 wire \rx_count[3] ;
 wire \rx_shift[0] ;
 wire \rx_shift[1] ;
 wire \rx_shift[2] ;
 wire \rx_shift[3] ;
 wire \rx_shift[4] ;
 wire \rx_shift[5] ;
 wire \rx_shift[6] ;
 wire \rx_shift[7] ;
 wire \tx_count[0] ;
 wire \tx_count[1] ;
 wire \tx_count[2] ;

 sky130_fd_sc_hd__inv_2 _044_ (.A(cs_n),
    .Y(_011_));
 sky130_fd_sc_hd__inv_2 _045_ (.A(\tx_count[2] ),
    .Y(_033_));
 sky130_fd_sc_hd__inv_2 _046_ (.A(sclk),
    .Y(_008_));
 sky130_fd_sc_hd__or4b_2 _047_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .C(\rx_count[2] ),
    .D_N(\rx_count[3] ),
    .X(_034_));
 sky130_fd_sc_hd__and2b_2 _048_ (.A_N(\rx_count[0] ),
    .B(_034_),
    .X(_000_));
 sky130_fd_sc_hd__xor2_2 _049_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .X(_001_));
 sky130_fd_sc_hd__a21oi_2 _050_ (.A1(\rx_count[1] ),
    .A2(\rx_count[0] ),
    .B1(\rx_count[2] ),
    .Y(_035_));
 sky130_fd_sc_hd__and3_2 _051_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .C(\rx_count[2] ),
    .X(_036_));
 sky130_fd_sc_hd__nor2_2 _052_ (.A(_035_),
    .B(_036_),
    .Y(_002_));
 sky130_fd_sc_hd__xor2_2 _053_ (.A(\rx_count[3] ),
    .B(_036_),
    .X(_003_));
 sky130_fd_sc_hd__nand2_2 _054_ (.A(\tx_count[0] ),
    .B(\tx_count[1] ),
    .Y(_037_));
 sky130_fd_sc_hd__o21ai_2 _055_ (.A1(_033_),
    .A2(_037_),
    .B1(\tx_count[0] ),
    .Y(_004_));
 sky130_fd_sc_hd__or2_2 _056_ (.A(\tx_count[0] ),
    .B(\tx_count[1] ),
    .X(_038_));
 sky130_fd_sc_hd__mux2_1 _057_ (.A0(\tx_count[2] ),
    .A1(_038_),
    .S(_037_),
    .X(_005_));
 sky130_fd_sc_hd__nand2_2 _058_ (.A(_033_),
    .B(_037_),
    .Y(_006_));
 sky130_fd_sc_hd__mux4_2 _059_ (.A0(tx_byte[3]),
    .A1(tx_byte[2]),
    .A2(tx_byte[1]),
    .A3(tx_byte[0]),
    .S0(\tx_count[0] ),
    .S1(\tx_count[1] ),
    .X(_039_));
 sky130_fd_sc_hd__nand2b_2 _060_ (.A_N(tx_byte[6]),
    .B(\tx_count[0] ),
    .Y(_040_));
 sky130_fd_sc_hd__o21ba_2 _061_ (.A1(\tx_count[0] ),
    .A2(tx_byte[7]),
    .B1_N(\tx_count[1] ),
    .X(_041_));
 sky130_fd_sc_hd__mux2_1 _062_ (.A0(tx_byte[5]),
    .A1(tx_byte[4]),
    .S(\tx_count[0] ),
    .X(_042_));
 sky130_fd_sc_hd__a221o_2 _063_ (.A1(_040_),
    .A2(_041_),
    .B1(_042_),
    .B2(\tx_count[1] ),
    .C1(\tx_count[2] ),
    .X(_043_));
 sky130_fd_sc_hd__o21a_2 _064_ (.A1(_033_),
    .A2(_039_),
    .B1(_043_),
    .X(miso));
 sky130_fd_sc_hd__mux2_1 _065_ (.A0(\rx_shift[0] ),
    .A1(rx_byte[0]),
    .S(_034_),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _066_ (.A0(\rx_shift[1] ),
    .A1(rx_byte[1]),
    .S(_034_),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _067_ (.A0(\rx_shift[2] ),
    .A1(rx_byte[2]),
    .S(_034_),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _068_ (.A0(\rx_shift[3] ),
    .A1(rx_byte[3]),
    .S(_034_),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _069_ (.A0(\rx_shift[4] ),
    .A1(rx_byte[4]),
    .S(_034_),
    .X(_029_));
 sky130_fd_sc_hd__mux2_1 _070_ (.A0(\rx_shift[5] ),
    .A1(rx_byte[5]),
    .S(_034_),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _071_ (.A0(\rx_shift[6] ),
    .A1(rx_byte[6]),
    .S(_034_),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _072_ (.A0(\rx_shift[7] ),
    .A1(rx_byte[7]),
    .S(_034_),
    .X(_032_));
 sky130_fd_sc_hd__inv_2 _073_ (.A(cs_n),
    .Y(_009_));
 sky130_fd_sc_hd__inv_2 _074_ (.A(cs_n),
    .Y(_007_));
 sky130_fd_sc_hd__inv_2 _075_ (.A(sclk),
    .Y(_010_));
 sky130_fd_sc_hd__inv_2 _076_ (.A(sclk),
    .Y(_012_));
 sky130_fd_sc_hd__inv_2 _077_ (.A(cs_n),
    .Y(_013_));
 sky130_fd_sc_hd__inv_2 _078_ (.A(cs_n),
    .Y(_014_));
 sky130_fd_sc_hd__inv_2 _079_ (.A(cs_n),
    .Y(_015_));
 sky130_fd_sc_hd__inv_2 _080_ (.A(cs_n),
    .Y(_016_));
 sky130_fd_sc_hd__inv_2 _081_ (.A(cs_n),
    .Y(_017_));
 sky130_fd_sc_hd__inv_2 _082_ (.A(cs_n),
    .Y(_018_));
 sky130_fd_sc_hd__inv_2 _083_ (.A(cs_n),
    .Y(_019_));
 sky130_fd_sc_hd__inv_2 _084_ (.A(cs_n),
    .Y(_020_));
 sky130_fd_sc_hd__inv_2 _085_ (.A(cs_n),
    .Y(_021_));
 sky130_fd_sc_hd__inv_2 _086_ (.A(cs_n),
    .Y(_022_));
 sky130_fd_sc_hd__inv_2 _087_ (.A(cs_n),
    .Y(_023_));
 sky130_fd_sc_hd__inv_2 _088_ (.A(cs_n),
    .Y(_024_));
 sky130_fd_sc_hd__dfxtp_2 _089_ (.CLK(cs_n),
    .D(_025_),
    .Q(rx_byte[0]));
 sky130_fd_sc_hd__dfxtp_2 _090_ (.CLK(cs_n),
    .D(_026_),
    .Q(rx_byte[1]));
 sky130_fd_sc_hd__dfxtp_2 _091_ (.CLK(cs_n),
    .D(_027_),
    .Q(rx_byte[2]));
 sky130_fd_sc_hd__dfxtp_2 _092_ (.CLK(cs_n),
    .D(_028_),
    .Q(rx_byte[3]));
 sky130_fd_sc_hd__dfxtp_2 _093_ (.CLK(cs_n),
    .D(_029_),
    .Q(rx_byte[4]));
 sky130_fd_sc_hd__dfxtp_2 _094_ (.CLK(cs_n),
    .D(_030_),
    .Q(rx_byte[5]));
 sky130_fd_sc_hd__dfxtp_2 _095_ (.CLK(cs_n),
    .D(_031_),
    .Q(rx_byte[6]));
 sky130_fd_sc_hd__dfxtp_2 _096_ (.CLK(cs_n),
    .D(_032_),
    .Q(rx_byte[7]));
 sky130_fd_sc_hd__dfrtp_2 _097_ (.CLK(_008_),
    .D(_004_),
    .RESET_B(_007_),
    .Q(\tx_count[0] ));
 sky130_fd_sc_hd__dfrtp_2 _098_ (.CLK(_010_),
    .D(_005_),
    .RESET_B(_009_),
    .Q(\tx_count[1] ));
 sky130_fd_sc_hd__dfrtp_2 _099_ (.CLK(_012_),
    .D(_006_),
    .RESET_B(_011_),
    .Q(\tx_count[2] ));
 sky130_fd_sc_hd__dfrtp_2 _100_ (.CLK(sclk),
    .D(mosi),
    .RESET_B(_013_),
    .Q(\rx_shift[0] ));
 sky130_fd_sc_hd__dfrtp_2 _101_ (.CLK(sclk),
    .D(\rx_shift[0] ),
    .RESET_B(_014_),
    .Q(\rx_shift[1] ));
 sky130_fd_sc_hd__dfrtp_2 _102_ (.CLK(sclk),
    .D(\rx_shift[1] ),
    .RESET_B(_015_),
    .Q(\rx_shift[2] ));
 sky130_fd_sc_hd__dfrtp_2 _103_ (.CLK(sclk),
    .D(\rx_shift[2] ),
    .RESET_B(_016_),
    .Q(\rx_shift[3] ));
 sky130_fd_sc_hd__dfrtp_2 _104_ (.CLK(sclk),
    .D(\rx_shift[3] ),
    .RESET_B(_017_),
    .Q(\rx_shift[4] ));
 sky130_fd_sc_hd__dfrtp_2 _105_ (.CLK(sclk),
    .D(\rx_shift[4] ),
    .RESET_B(_018_),
    .Q(\rx_shift[5] ));
 sky130_fd_sc_hd__dfrtp_2 _106_ (.CLK(sclk),
    .D(\rx_shift[5] ),
    .RESET_B(_019_),
    .Q(\rx_shift[6] ));
 sky130_fd_sc_hd__dfrtp_2 _107_ (.CLK(sclk),
    .D(\rx_shift[6] ),
    .RESET_B(_020_),
    .Q(\rx_shift[7] ));
 sky130_fd_sc_hd__dfrtp_2 _108_ (.CLK(sclk),
    .D(_000_),
    .RESET_B(_021_),
    .Q(\rx_count[0] ));
 sky130_fd_sc_hd__dfrtp_2 _109_ (.CLK(sclk),
    .D(_001_),
    .RESET_B(_022_),
    .Q(\rx_count[1] ));
 sky130_fd_sc_hd__dfrtp_2 _110_ (.CLK(sclk),
    .D(_002_),
    .RESET_B(_023_),
    .Q(\rx_count[2] ));
 sky130_fd_sc_hd__dfrtp_2 _111_ (.CLK(sclk),
    .D(_003_),
    .RESET_B(_024_),
    .Q(\rx_count[3] ));
endmodule

module h04_spi_slave (cs_n,
    miso,
    mosi,
    sclk,
    rx_byte,
    tx_byte);
 input cs_n;
 output miso;
 input mosi;
 input sclk;
 output [7:0] rx_byte;
 input [7:0] tx_byte;

 wire _000_;
 wire _001_;
 wire _002_;
 wire _003_;
 wire _004_;
 wire _005_;
 wire _006_;
 wire net22;
 wire net35;
 wire net21;
 wire net36;
 wire net20;
 wire clknet_0_sclk;
 wire net23;
 wire net24;
 wire net25;
 wire net26;
 wire net27;
 wire net28;
 wire net29;
 wire net30;
 wire net31;
 wire net32;
 wire net33;
 wire net34;
 wire _025_;
 wire _026_;
 wire _027_;
 wire _028_;
 wire _029_;
 wire _030_;
 wire _031_;
 wire _032_;
 wire _033_;
 wire _034_;
 wire _035_;
 wire _036_;
 wire _037_;
 wire _038_;
 wire _039_;
 wire _040_;
 wire _041_;
 wire _042_;
 wire _043_;
 wire net10;
 wire net1;
 wire net11;
 wire net12;
 wire net13;
 wire net14;
 wire net15;
 wire net16;
 wire net17;
 wire net18;
 wire \rx_count[0] ;
 wire \rx_count[1] ;
 wire \rx_count[2] ;
 wire \rx_count[3] ;
 wire \rx_shift[0] ;
 wire \rx_shift[1] ;
 wire \rx_shift[2] ;
 wire \rx_shift[3] ;
 wire \rx_shift[4] ;
 wire \rx_shift[5] ;
 wire \rx_shift[6] ;
 wire \rx_shift[7] ;
 wire net2;
 wire net3;
 wire net4;
 wire net5;
 wire net6;
 wire net7;
 wire net8;
 wire net9;
 wire \tx_count[0] ;
 wire \tx_count[1] ;
 wire \tx_count[2] ;
 wire net19;
 wire clknet_1_0__leaf_sclk;
 wire clknet_1_1__leaf_sclk;
 wire clknet_0_cs_n;
 wire clknet_1_0__leaf_cs_n;
 wire clknet_1_1__leaf_cs_n;

 sky130_fd_sc_hd__decap_3 FILLER_0_21 ();
 sky130_fd_sc_hd__decap_3 FILLER_0_24 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_27 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_29 ();
 sky130_fd_sc_hd__fill_1 FILLER_0_3 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_57 ();
 sky130_fd_sc_hd__decap_3 FILLER_0_76 ();
 sky130_fd_sc_hd__decap_3 FILLER_0_79 ();
 sky130_fd_sc_hd__fill_2 FILLER_0_82 ();
 sky130_fd_sc_hd__decap_3 FILLER_0_94 ();
 sky130_fd_sc_hd__decap_3 FILLER_0_97 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_12 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_15 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_18 ();
 sky130_fd_sc_hd__fill_1 FILLER_10_29 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_72 ();
 sky130_fd_sc_hd__fill_1 FILLER_10_75 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_9 ();
 sky130_fd_sc_hd__fill_2 FILLER_10_90 ();
 sky130_fd_sc_hd__decap_3 FILLER_10_95 ();
 sky130_fd_sc_hd__fill_2 FILLER_10_98 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_27 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_36 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_39 ();
 sky130_fd_sc_hd__fill_1 FILLER_11_42 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_46 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_49 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_52 ();
 sky130_fd_sc_hd__fill_1 FILLER_11_55 ();
 sky130_fd_sc_hd__fill_2 FILLER_11_67 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_82 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_85 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_88 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_91 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_94 ();
 sky130_fd_sc_hd__decap_3 FILLER_11_97 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_10 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_13 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_24 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_27 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_29 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_32 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_35 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_50 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_53 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_56 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_12_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_62 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_65 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_68 ();
 sky130_fd_sc_hd__fill_2 FILLER_12_71 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_79 ();
 sky130_fd_sc_hd__fill_2 FILLER_12_82 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_85 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_88 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_91 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_94 ();
 sky130_fd_sc_hd__decap_3 FILLER_12_97 ();
 sky130_fd_sc_hd__decap_3 FILLER_13_10 ();
 sky130_fd_sc_hd__decap_3 FILLER_13_27 ();
 sky130_fd_sc_hd__fill_1 FILLER_13_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_13_30 ();
 sky130_fd_sc_hd__fill_2 FILLER_13_33 ();
 sky130_fd_sc_hd__decap_3 FILLER_13_51 ();
 sky130_fd_sc_hd__fill_2 FILLER_13_54 ();
 sky130_fd_sc_hd__decap_3 FILLER_13_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_13_60 ();
 sky130_fd_sc_hd__decap_3 FILLER_13_7 ();
 sky130_fd_sc_hd__fill_1 FILLER_13_74 ();
 sky130_fd_sc_hd__fill_1 FILLER_13_78 ();
 sky130_fd_sc_hd__fill_1 FILLER_14_27 ();
 sky130_fd_sc_hd__fill_2 FILLER_14_29 ();
 sky130_fd_sc_hd__decap_3 FILLER_14_56 ();
 sky130_fd_sc_hd__decap_3 FILLER_14_59 ();
 sky130_fd_sc_hd__fill_1 FILLER_14_83 ();
 sky130_fd_sc_hd__decap_3 FILLER_14_85 ();
 sky130_fd_sc_hd__decap_3 FILLER_14_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_14_91 ();
 sky130_fd_sc_hd__decap_3 FILLER_14_95 ();
 sky130_fd_sc_hd__fill_2 FILLER_14_98 ();
 sky130_fd_sc_hd__fill_2 FILLER_15_12 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_3 ();
 sky130_fd_sc_hd__fill_2 FILLER_15_45 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_57 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_60 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_63 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_66 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_69 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_72 ();
 sky130_fd_sc_hd__fill_1 FILLER_15_75 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_89 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_9 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_92 ();
 sky130_fd_sc_hd__decap_3 FILLER_15_95 ();
 sky130_fd_sc_hd__fill_2 FILLER_15_98 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_12 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_15 ();
 sky130_fd_sc_hd__fill_2 FILLER_16_18 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_29 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_65 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_68 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_71 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_74 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_77 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_80 ();
 sky130_fd_sc_hd__fill_1 FILLER_16_83 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_85 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_88 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_9 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_91 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_94 ();
 sky130_fd_sc_hd__decap_3 FILLER_16_97 ();
 sky130_fd_sc_hd__decap_3 FILLER_1_21 ();
 sky130_fd_sc_hd__fill_2 FILLER_1_24 ();
 sky130_fd_sc_hd__fill_1 FILLER_1_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_1_52 ();
 sky130_fd_sc_hd__fill_1 FILLER_1_55 ();
 sky130_fd_sc_hd__decap_3 FILLER_1_74 ();
 sky130_fd_sc_hd__decap_3 FILLER_1_77 ();
 sky130_fd_sc_hd__fill_2 FILLER_1_80 ();
 sky130_fd_sc_hd__fill_1 FILLER_1_99 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_24 ();
 sky130_fd_sc_hd__fill_1 FILLER_2_27 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_29 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_32 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_35 ();
 sky130_fd_sc_hd__fill_2 FILLER_2_38 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_57 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_60 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_63 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_66 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_69 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_72 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_75 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_78 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_81 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_85 ();
 sky130_fd_sc_hd__decap_3 FILLER_2_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_2_91 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_14 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_38 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_41 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_44 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_47 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_50 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_53 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_57 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_60 ();
 sky130_fd_sc_hd__fill_2 FILLER_3_63 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_86 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_89 ();
 sky130_fd_sc_hd__fill_2 FILLER_3_9 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_92 ();
 sky130_fd_sc_hd__decap_3 FILLER_3_95 ();
 sky130_fd_sc_hd__fill_2 FILLER_3_98 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_12 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_15 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_18 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_21 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_24 ();
 sky130_fd_sc_hd__fill_1 FILLER_4_27 ();
 sky130_fd_sc_hd__fill_1 FILLER_4_29 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_33 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_36 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_39 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_42 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_45 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_48 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_51 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_54 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_57 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_60 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_63 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_66 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_69 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_72 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_75 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_81 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_85 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_88 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_9 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_91 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_94 ();
 sky130_fd_sc_hd__decap_3 FILLER_4_97 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_11 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_14 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_17 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_20 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_23 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_26 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_29 ();
 sky130_fd_sc_hd__decap_3 FILLER_5_32 ();
 sky130_fd_sc_hd__fill_2 FILLER_5_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_27 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_29 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_3 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_32 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_35 ();
 sky130_fd_sc_hd__fill_2 FILLER_6_38 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_43 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_46 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_80 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_83 ();
 sky130_fd_sc_hd__decap_3 FILLER_6_85 ();
 sky130_fd_sc_hd__fill_1 FILLER_6_9 ();
 sky130_fd_sc_hd__decap_3 FILLER_7_24 ();
 sky130_fd_sc_hd__decap_3 FILLER_7_48 ();
 sky130_fd_sc_hd__decap_3 FILLER_7_51 ();
 sky130_fd_sc_hd__fill_2 FILLER_7_54 ();
 sky130_fd_sc_hd__decap_3 FILLER_7_57 ();
 sky130_fd_sc_hd__fill_1 FILLER_7_60 ();
 sky130_fd_sc_hd__fill_2 FILLER_7_98 ();
 sky130_fd_sc_hd__fill_2 FILLER_8_11 ();
 sky130_fd_sc_hd__decap_3 FILLER_8_25 ();
 sky130_fd_sc_hd__fill_2 FILLER_8_29 ();
 sky130_fd_sc_hd__fill_1 FILLER_8_51 ();
 sky130_fd_sc_hd__fill_1 FILLER_8_83 ();
 sky130_fd_sc_hd__decap_3 FILLER_8_85 ();
 sky130_fd_sc_hd__decap_3 FILLER_8_88 ();
 sky130_fd_sc_hd__fill_1 FILLER_8_91 ();
 sky130_fd_sc_hd__decap_3 FILLER_9_12 ();
 sky130_fd_sc_hd__fill_1 FILLER_9_15 ();
 sky130_fd_sc_hd__decap_3 FILLER_9_3 ();
 sky130_fd_sc_hd__fill_2 FILLER_9_57 ();
 sky130_fd_sc_hd__decap_3 FILLER_9_6 ();
 sky130_fd_sc_hd__decap_3 FILLER_9_9 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Left_17 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_0_Right_0 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Left_27 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_10_Right_10 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Left_28 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_11_Right_11 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Left_29 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_12_Right_12 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Left_30 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_13_Right_13 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Left_31 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_14_Right_14 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Left_32 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_15_Right_15 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Left_33 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_16_Right_16 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Left_18 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_1_Right_1 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Left_19 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_2_Right_2 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Left_20 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_3_Right_3 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Left_21 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_4_Right_4 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Left_22 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_5_Right_5 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Left_23 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_6_Right_6 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Left_24 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_7_Right_7 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Left_25 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_8_Right_8 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Left_26 ();
 sky130_fd_sc_hd__decap_3 PHY_EDGE_ROW_9_Right_9 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_34 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_35 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_0_36 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_50 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_10_51 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_11_52 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_53 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_12_54 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_13_55 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_56 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_14_57 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_15_58 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_59 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_60 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_16_61 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_1_37 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_38 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_2_39 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_3_40 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_41 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_4_42 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_5_43 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_44 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_6_45 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_7_46 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_47 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_8_48 ();
 sky130_fd_sc_hd__tapvpwrvgnd_1 TAP_TAPCELL_ROW_9_49 ();
 sky130_fd_sc_hd__inv_2 _044__19 (.A(clknet_1_0__leaf_cs_n),
    .Y(net19));
 sky130_fd_sc_hd__inv_2 _045_ (.A(\tx_count[2] ),
    .Y(_033_));
 sky130_fd_sc_hd__inv_2 _046__34 (.A(clknet_1_0__leaf_sclk),
    .Y(net34));
 sky130_fd_sc_hd__or4b_2 _047_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .C(\rx_count[2] ),
    .D_N(\rx_count[3] ),
    .X(_034_));
 sky130_fd_sc_hd__and2b_2 _048_ (.A_N(\rx_count[0] ),
    .B(_034_),
    .X(_000_));
 sky130_fd_sc_hd__xor2_2 _049_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .X(_001_));
 sky130_fd_sc_hd__a21oi_2 _050_ (.A1(\rx_count[1] ),
    .A2(\rx_count[0] ),
    .B1(\rx_count[2] ),
    .Y(_035_));
 sky130_fd_sc_hd__and3_2 _051_ (.A(\rx_count[1] ),
    .B(\rx_count[0] ),
    .C(\rx_count[2] ),
    .X(_036_));
 sky130_fd_sc_hd__nor2_2 _052_ (.A(_035_),
    .B(_036_),
    .Y(_002_));
 sky130_fd_sc_hd__xor2_2 _053_ (.A(\rx_count[3] ),
    .B(_036_),
    .X(_003_));
 sky130_fd_sc_hd__nand2_2 _054_ (.A(\tx_count[0] ),
    .B(\tx_count[1] ),
    .Y(_037_));
 sky130_fd_sc_hd__o21ai_2 _055_ (.A1(_033_),
    .A2(_037_),
    .B1(\tx_count[0] ),
    .Y(_004_));
 sky130_fd_sc_hd__or2_2 _056_ (.A(\tx_count[0] ),
    .B(\tx_count[1] ),
    .X(_038_));
 sky130_fd_sc_hd__mux2_1 _057_ (.A0(\tx_count[2] ),
    .A1(_038_),
    .S(_037_),
    .X(_005_));
 sky130_fd_sc_hd__nand2_2 _058_ (.A(_033_),
    .B(_037_),
    .Y(_006_));
 sky130_fd_sc_hd__mux4_2 _059_ (.A0(net5),
    .A1(net4),
    .A2(net3),
    .A3(net2),
    .S0(\tx_count[0] ),
    .S1(\tx_count[1] ),
    .X(_039_));
 sky130_fd_sc_hd__nand2b_2 _060_ (.A_N(net8),
    .B(\tx_count[0] ),
    .Y(_040_));
 sky130_fd_sc_hd__o21ba_2 _061_ (.A1(\tx_count[0] ),
    .A2(net9),
    .B1_N(\tx_count[1] ),
    .X(_041_));
 sky130_fd_sc_hd__mux2_1 _062_ (.A0(net7),
    .A1(net6),
    .S(\tx_count[0] ),
    .X(_042_));
 sky130_fd_sc_hd__a221o_2 _063_ (.A1(_040_),
    .A2(_041_),
    .B1(_042_),
    .B2(\tx_count[1] ),
    .C1(\tx_count[2] ),
    .X(_043_));
 sky130_fd_sc_hd__o21a_2 _064_ (.A1(_033_),
    .A2(_039_),
    .B1(_043_),
    .X(net10));
 sky130_fd_sc_hd__mux2_1 _065_ (.A0(\rx_shift[0] ),
    .A1(net11),
    .S(_034_),
    .X(_025_));
 sky130_fd_sc_hd__mux2_1 _066_ (.A0(\rx_shift[1] ),
    .A1(net12),
    .S(_034_),
    .X(_026_));
 sky130_fd_sc_hd__mux2_1 _067_ (.A0(\rx_shift[2] ),
    .A1(net13),
    .S(_034_),
    .X(_027_));
 sky130_fd_sc_hd__mux2_1 _068_ (.A0(\rx_shift[3] ),
    .A1(net14),
    .S(_034_),
    .X(_028_));
 sky130_fd_sc_hd__mux2_1 _069_ (.A0(\rx_shift[4] ),
    .A1(net15),
    .S(_034_),
    .X(_029_));
 sky130_fd_sc_hd__mux2_1 _070_ (.A0(\rx_shift[5] ),
    .A1(net16),
    .S(_034_),
    .X(_030_));
 sky130_fd_sc_hd__mux2_1 _071_ (.A0(\rx_shift[6] ),
    .A1(net17),
    .S(_034_),
    .X(_031_));
 sky130_fd_sc_hd__mux2_1 _072_ (.A0(\rx_shift[7] ),
    .A1(net18),
    .S(_034_),
    .X(_032_));
 sky130_fd_sc_hd__inv_2 _073__20 (.A(clknet_1_0__leaf_cs_n),
    .Y(net20));
 sky130_fd_sc_hd__inv_2 _074__21 (.A(clknet_1_0__leaf_cs_n),
    .Y(net21));
 sky130_fd_sc_hd__inv_2 _075__35 (.A(clknet_1_0__leaf_sclk),
    .Y(net35));
 sky130_fd_sc_hd__inv_2 _076__36 (.A(clknet_1_0__leaf_sclk),
    .Y(net36));
 sky130_fd_sc_hd__inv_2 _077__22 (.A(clknet_1_0__leaf_cs_n),
    .Y(net22));
 sky130_fd_sc_hd__inv_2 _078__23 (.A(clknet_1_0__leaf_cs_n),
    .Y(net23));
 sky130_fd_sc_hd__inv_2 _079__24 (.A(clknet_1_0__leaf_cs_n),
    .Y(net24));
 sky130_fd_sc_hd__inv_2 _080__25 (.A(clknet_1_0__leaf_cs_n),
    .Y(net25));
 sky130_fd_sc_hd__inv_2 _081__26 (.A(clknet_1_0__leaf_cs_n),
    .Y(net26));
 sky130_fd_sc_hd__inv_2 _082__27 (.A(clknet_1_1__leaf_cs_n),
    .Y(net27));
 sky130_fd_sc_hd__inv_2 _083__28 (.A(clknet_1_1__leaf_cs_n),
    .Y(net28));
 sky130_fd_sc_hd__inv_2 _084__29 (.A(clknet_1_1__leaf_cs_n),
    .Y(net29));
 sky130_fd_sc_hd__inv_2 _085__30 (.A(clknet_1_1__leaf_cs_n),
    .Y(net30));
 sky130_fd_sc_hd__inv_2 _086__31 (.A(clknet_1_1__leaf_cs_n),
    .Y(net31));
 sky130_fd_sc_hd__inv_2 _087__32 (.A(clknet_1_1__leaf_cs_n),
    .Y(net32));
 sky130_fd_sc_hd__inv_2 _088__33 (.A(clknet_1_1__leaf_cs_n),
    .Y(net33));
 sky130_fd_sc_hd__dfxtp_2 _089_ (.CLK(clknet_1_0__leaf_cs_n),
    .D(_025_),
    .Q(net11));
 sky130_fd_sc_hd__dfxtp_2 _090_ (.CLK(clknet_1_0__leaf_cs_n),
    .D(_026_),
    .Q(net12));
 sky130_fd_sc_hd__dfxtp_2 _091_ (.CLK(clknet_1_0__leaf_cs_n),
    .D(_027_),
    .Q(net13));
 sky130_fd_sc_hd__dfxtp_2 _092_ (.CLK(clknet_1_0__leaf_cs_n),
    .D(_028_),
    .Q(net14));
 sky130_fd_sc_hd__dfxtp_2 _093_ (.CLK(clknet_1_1__leaf_cs_n),
    .D(_029_),
    .Q(net15));
 sky130_fd_sc_hd__dfxtp_2 _094_ (.CLK(clknet_1_1__leaf_cs_n),
    .D(_030_),
    .Q(net16));
 sky130_fd_sc_hd__dfxtp_2 _095_ (.CLK(clknet_1_1__leaf_cs_n),
    .D(_031_),
    .Q(net17));
 sky130_fd_sc_hd__dfxtp_2 _096_ (.CLK(clknet_1_1__leaf_cs_n),
    .D(_032_),
    .Q(net18));
 sky130_fd_sc_hd__dfrtp_2 _097_ (.CLK(net34),
    .D(_004_),
    .RESET_B(net21),
    .Q(\tx_count[0] ));
 sky130_fd_sc_hd__dfrtp_2 _098_ (.CLK(net35),
    .D(_005_),
    .RESET_B(net20),
    .Q(\tx_count[1] ));
 sky130_fd_sc_hd__dfrtp_2 _099_ (.CLK(net36),
    .D(_006_),
    .RESET_B(net19),
    .Q(\tx_count[2] ));
 sky130_fd_sc_hd__dfrtp_2 _100_ (.CLK(clknet_1_0__leaf_sclk),
    .D(net1),
    .RESET_B(net22),
    .Q(\rx_shift[0] ));
 sky130_fd_sc_hd__dfrtp_2 _101_ (.CLK(clknet_1_0__leaf_sclk),
    .D(\rx_shift[0] ),
    .RESET_B(net23),
    .Q(\rx_shift[1] ));
 sky130_fd_sc_hd__dfrtp_2 _102_ (.CLK(clknet_1_0__leaf_sclk),
    .D(\rx_shift[1] ),
    .RESET_B(net24),
    .Q(\rx_shift[2] ));
 sky130_fd_sc_hd__dfrtp_2 _103_ (.CLK(clknet_1_0__leaf_sclk),
    .D(\rx_shift[2] ),
    .RESET_B(net25),
    .Q(\rx_shift[3] ));
 sky130_fd_sc_hd__dfrtp_2 _104_ (.CLK(clknet_1_0__leaf_sclk),
    .D(\rx_shift[3] ),
    .RESET_B(net26),
    .Q(\rx_shift[4] ));
 sky130_fd_sc_hd__dfrtp_2 _105_ (.CLK(clknet_1_1__leaf_sclk),
    .D(\rx_shift[4] ),
    .RESET_B(net27),
    .Q(\rx_shift[5] ));
 sky130_fd_sc_hd__dfrtp_2 _106_ (.CLK(clknet_1_1__leaf_sclk),
    .D(\rx_shift[5] ),
    .RESET_B(net28),
    .Q(\rx_shift[6] ));
 sky130_fd_sc_hd__dfrtp_2 _107_ (.CLK(clknet_1_1__leaf_sclk),
    .D(\rx_shift[6] ),
    .RESET_B(net29),
    .Q(\rx_shift[7] ));
 sky130_fd_sc_hd__dfrtp_2 _108_ (.CLK(clknet_1_1__leaf_sclk),
    .D(_000_),
    .RESET_B(net30),
    .Q(\rx_count[0] ));
 sky130_fd_sc_hd__dfrtp_2 _109_ (.CLK(clknet_1_1__leaf_sclk),
    .D(_001_),
    .RESET_B(net31),
    .Q(\rx_count[1] ));
 sky130_fd_sc_hd__dfrtp_2 _110_ (.CLK(clknet_1_1__leaf_sclk),
    .D(_002_),
    .RESET_B(net32),
    .Q(\rx_count[2] ));
 sky130_fd_sc_hd__dfrtp_2 _111_ (.CLK(clknet_1_1__leaf_sclk),
    .D(_003_),
    .RESET_B(net33),
    .Q(\rx_count[3] ));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_cs_n (.A(cs_n),
    .X(clknet_0_cs_n));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_0_sclk (.A(sclk),
    .X(clknet_0_sclk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_1_0__f_cs_n (.A(clknet_0_cs_n),
    .X(clknet_1_0__leaf_cs_n));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_1_0__f_sclk (.A(clknet_0_sclk),
    .X(clknet_1_0__leaf_sclk));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_1_1__f_cs_n (.A(clknet_0_cs_n),
    .X(clknet_1_1__leaf_cs_n));
 sky130_fd_sc_hd__clkbuf_16 clkbuf_1_1__f_sclk (.A(clknet_0_sclk),
    .X(clknet_1_1__leaf_sclk));
 sky130_fd_sc_hd__clkinvlp_4 clkload0 (.A(clknet_1_1__leaf_sclk));
 sky130_fd_sc_hd__inv_2 clkload1 (.A(clknet_1_1__leaf_cs_n));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input1 (.A(mosi),
    .X(net1));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input2 (.A(tx_byte[0]),
    .X(net2));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input3 (.A(tx_byte[1]),
    .X(net3));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input4 (.A(tx_byte[2]),
    .X(net4));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input5 (.A(tx_byte[3]),
    .X(net5));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input6 (.A(tx_byte[4]),
    .X(net6));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input7 (.A(tx_byte[5]),
    .X(net7));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input8 (.A(tx_byte[6]),
    .X(net8));
 sky130_fd_sc_hd__clkdlybuf4s25_1 input9 (.A(tx_byte[7]),
    .X(net9));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output10 (.A(net10),
    .X(miso));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output11 (.A(net11),
    .X(rx_byte[0]));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output12 (.A(net12),
    .X(rx_byte[1]));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output13 (.A(net13),
    .X(rx_byte[2]));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output14 (.A(net14),
    .X(rx_byte[3]));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output15 (.A(net15),
    .X(rx_byte[4]));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output16 (.A(net16),
    .X(rx_byte[5]));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output17 (.A(net17),
    .X(rx_byte[6]));
 sky130_fd_sc_hd__clkdlybuf4s25_1 output18 (.A(net18),
    .X(rx_byte[7]));
endmodule
